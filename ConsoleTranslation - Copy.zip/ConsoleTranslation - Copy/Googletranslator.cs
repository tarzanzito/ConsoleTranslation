﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;



namespace ConsoleTranslation
{
    internal class Googletranslator : TranslatatorX //, ITranslatator
    {
        public const int MAX_TEXT_LEN = 4999;
        private const string URL_TRANSLATE = "https://translate.googleapis.com/translate_a/single";

        private readonly  HttpClient _httpClient = new();

        public async Task<string> TranslateTextAsync(string shortText, string sourceLang, string targetLang)
        {
            string translatedText = await TranslateAsync(shortText, sourceLang, targetLang, true);

            return translatedText;
        }

        public async Task<List<string>> TranslateTextListAsync(List<string> shortTextList, string sourceLang, string targetLang)
        {
            ValidateList(shortTextList);
            
            bool validateLangs = true;
            List<string> translatedList = new();

            foreach (string item in shortTextList)
            {
                string translatedText = await TranslateAsync(item, sourceLang, targetLang, validateLangs);
                translatedList.Add(translatedText);
                validateLangs = false;
            }

            return translatedList;
        }


        private async Task<string> TranslateAsync(string shortText, string sourceLang, string targetLang, bool validateLangs)
        {
            Validate(shortText, sourceLang, targetLang, validateLangs); 

            if (shortText.Trim() == string.Empty)
                return shortText;

            // "sl" = source language
            // "tl" = target language
            // "q" = query
            // "auto"
            //client=gtx
            //dt=t
            //q=text

            string translatedText = string.Empty;

            try
            {
                string queryString = $"client=gtx&sl={sourceLang}&tl={targetLang}&dt=t&q={WebUtility.UrlEncode(shortText)}";
                string url = $"{URL_TRANSLATE}?{queryString}";

                string httpResponse = await _httpClient.GetStringAsync(url);

                //httpResponse.EnsureSuccessStatusCode();

                // A resposta vem esquisita: [[["Olá mundo","Hello world",null,null,3]],null,"en"]
                using JsonDocument doc = JsonDocument.Parse(httpResponse);

                foreach (var item in doc.RootElement[0].EnumerateArray())
                {
                    translatedText += item[0].GetString();
                }
            }
            catch
            {
                throw;
            }
            finally
            {

            }

            return translatedText;
        }

    }
}


