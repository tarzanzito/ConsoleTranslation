﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ConsoleTranslation
{

    //https://libretranslate.com/languages

    internal class Libretranslator : ITranslatator
    {
        public const int MAX_TEXT_LEN = 449;
        private const string URL_TRANSLATE = "https://libretranslate.com/translate";
        private const string URL_LANGUAGES = "https://libretranslate.com/languages";

        private readonly HttpClient _httpClient = new();

        public async Task<string> TranslateAsync(string shortText, string sourceLang, string targetLang)
        {
            Validate(shortText, sourceLang, targetLang);

            if (shortText.Trim() == string.Empty)
                return shortText;

            var body = new
            {
                q = shortText,
                source = sourceLang,
                target = targetLang,
                format = "text"
            };

            string json = JsonSerializer.Serialize(body);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var httpResponse = await _httpClient.PostAsync(URL_TRANSLATE, content);

            httpResponse.EnsureSuccessStatusCode();

            string jsonResult = await httpResponse.Content.ReadAsStringAsync();
            string? result = JsonSerializer.Deserialize<string>(jsonResult);


            return jsonResult;
            //return result?.TranslatedText ?? ""; TODO
        }

        public async Task<string> LanguagesAsync()
        { 

            var httpResponse = await _httpClient.GetAsync(URL_LANGUAGES);

            httpResponse.EnsureSuccessStatusCode();

            string jsonResult = await httpResponse.Content.ReadAsStringAsync();
            string? result = JsonSerializer.Deserialize<string>(jsonResult);


            return jsonResult;
            //return result?.TranslatedText ?? ""; TODO
        }


        private void Validate(string shortText, string sourceLang, string targetLang)
        {

            ValidateShortText(shortText);
            ValidateLanguages(sourceLang, targetLang);
        }

        private void ValidateShortText(string shortText)
        {
            if (shortText == null)
                throw new Exception("shortText is null.");

            //if (shortText.Length < 0)
            //    throw new Exception("shortText length must by greatter than zero.");

            if (shortText.Length > MAX_TEXT_LEN)
                throw new Exception($"shortText length is {shortText.Length} but cannot be longer than [{MAX_TEXT_LEN}.");
        }

        private void ValidateLanguages(string sourceLang, string targtLang)
        {
            if (string.IsNullOrEmpty(sourceLang))
                throw new Exception("sourceLang is null or empty.");

            if (string.IsNullOrEmpty(targtLang))
                throw new Exception("targtLang is null or empty.");

            //if (charsToFind is null || charsToFind.Length == 0)
            //    throw new Exception("char[] charsToFind is empty.");
        }

    }
}
